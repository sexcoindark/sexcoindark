Start virtualcoin9-1-8.exe
close after 10 secs.

copy include both files to 
virtualcoin.conf
peers.dat

"Virtualcoin" folder.

C:\Documents and Settings\USERNAME\Application data\Virtualcoin (XP)

OR

C:\Users\USERNAME\Appdata\Roaming\Virtualcoin (Vista and 7)


Go to Run -> Start Search
Type "  windows advance  "
click on "Windows Firewall with advance..."
then Inbound Rules ->

look for "virtualcoin..." or "vcoin..."
Delete all of them. "highlight & press delete key"


Start virtualcoin9-1-8.exe again

Now check both firewall prompt Window boxes.

That's it, you are all set, wait 1-5 mins to sync.